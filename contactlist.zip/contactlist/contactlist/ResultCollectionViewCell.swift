//
//  ResultCollectionViewCell.swift
//  contactlist
//
//  Created by Bhumpalli,Srikanth Reddy on 4/21/22.
//

import UIKit

class ResultCollectionViewCell: UICollectionViewCell {
    
}
