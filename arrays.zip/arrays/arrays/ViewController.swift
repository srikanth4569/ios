//
//  ViewController.swift
//  arrays
//
//  Created by Bhumpalli,Srikanth Reddy on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var courseNumber: UILabel!
    
    @IBOutlet weak var crsTitle: UILabel!
    
    @IBOutlet weak var sesOffered: UILabel!
    @IBOutlet weak var previuosButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    let courses = [["img01","44555","network","security","fall 2022"],["img02","44643","ios","spring 2022"],["img03","44656","data streaming","fall 2022"]]
    
    var imageNumber = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //the details of the course is displayed in oth position (imagw,crsnum,srssem)
        
        displayImage.image = UIImage(named:courses[0][0])
        courseNumber.text = courses[0][1]
        crsTitle.text = courses[0][2]
        sesOffered.text = courses[0][3]
        //the previous button should be disabled
        previuosButton.isEnabled = false
        
    }


    @IBAction func previousButtonClicked(_ sender: UIButton) {
        
        // next button should be enabled
        nextButton.isEnabled = true
        //update the course details bt decreamenting image number
        imageNumber -= 1
        updateUI(imageNum: imageNumber)
        //ones we reach the begining of tyhe array previous button should be disabled
        if(imageNumber == 0){
            previuosButton.isEnabled = false
        }
    }

    @IBAction func nextButtonClicked(_ sender: UIButton) {
        
        //update the Ui of next course details by increamenting image number
        imageNumber += 1
        updateUI(imageNum: imageNumber)
        //previous  button should be enabled
        previuosButton.isEnabled = true
        // ones the user reach the end of array the next button should be disabled
        if(imageNumber == courses.count-1){
            nextButton.isEnabled = false
        }
    }
    func updateUI(imageNum:Int){
        
        displayImage.image = UIImage(named:courses[0][0])
        courseNumber.text = courses[imageNum][1]
        crsTitle.text = courses[imageNum][2]
        sesOffered.text = courses[imageNum][3]
    
}
}
