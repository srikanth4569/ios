//
//  ViewController.swift
//  coordinates
//
//  Created by Bhumpalli,Srikanth Reddy on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgeViewOutlet: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minX = imgeViewOutlet.frame.minX;
        let minY = imgeViewOutlet.frame.minY;
        print("(\(minX),\(minY)");
        
        let maxX = imgeViewOutlet.frame.maxX;
        let maxY = imgeViewOutlet.frame.maxY;
        print("(\(maxX),\(maxY)");
        
        let midX = imgeViewOutlet.frame.midX;
        let midY = imgeViewOutlet.frame.midY;
        print("(\(midX),\(midY)");
        
        // chnag ethe location of the car to upper left corner
        imgeViewOutlet.frame.origin.x = 0
        imgeViewOutlet.frame.origin.y = 0
        
        // chnag ethe location of the car to upper right corner
        imgeViewOutlet.frame.origin.x = 314
        imgeViewOutlet.frame.origin.y = 0
        
        // chnag ethe location of the car to below left corner
        
        imgeViewOutlet.frame.origin.x = 0
        imgeViewOutlet.frame.origin.y = 796
        
        
        // chnag ethe location of the car to below right corner
        imgeViewOutlet.frame.origin.x = 314
        imgeViewOutlet.frame.origin.y = 796
        
        
        // changing the location to center
        
        imgeViewOutlet.frame.origin.x = 314/2
        imgeViewOutlet.frame.origin.y = 796/2
        
        
        
        
        
        
        
    }


}

