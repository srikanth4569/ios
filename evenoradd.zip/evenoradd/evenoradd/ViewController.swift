//
//  ViewController.swift
//  evenoradd
//
//  Created by Bhumpalli,Srikanth Reddy on 2/8/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var numberTextfield: UITextField!
    
    
    @IBOutlet weak var displayLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButton(_ sender: UIButton) {
    
    
   var enteredNumber = Int(numberTextfield.text!)
         
        if (enteredNumber!%2 == 0)
        {
       displayLable.text = "given number \(enteredNumber!) is even"
        }
                           else{
       displayLable.text = "given numnber \(enteredNumber!) is odd number"
   }
    
        
    
}
}

