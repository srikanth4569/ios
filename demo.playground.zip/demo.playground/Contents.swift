import UIKit
import Foundation

var greeting = "Hello, playground"
print("hi",10,12.25)


//string interpolation
//\(variablename)
var name = "Srikanth"
//helloo,srikanth
var grade = 89.92
print("hello,\(name) your grade is \(grade)")


var proLan = "swift"
print("i like ios subject by using \(proLan) language")
var age = 23
print("You are \(age) years old and in another \(age)years, you will be \(age * 2)")

// \r carraige return
print ("Hello All,\rWelcome to Swift programming")
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print ("Welcome to Swift Programming", terminator:"-")
print("spring 2022")
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
print("the old pattern is ", terminator: "---")
print(1,2,3,4,5,6, separator:"$")


// worksheet
var httpError = (errorCode : 404 , errorMessage : "page not found")

print(httpError)
print(httpError.errorCode , terminator : ":")
print(httpError.errorMessage)

var sName = ("srikanth","reddy")
var fName = sName.0
var lName = sName.1
print(fName,terminator:",")
print(lName)

var origin = (x:0,y:0)
var point = origin
print(point.x,point.y)

let city=(place:"maryville",population:12000)
let (cityName,cityPopulation)=(city.0,city.1)
print(cityName)
print(cityPopulation)
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

