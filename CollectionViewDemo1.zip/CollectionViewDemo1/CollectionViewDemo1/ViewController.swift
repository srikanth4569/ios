//
//  ViewController.swift
//  CollectionViewDemo1
//
//  Created by Bhumpalli,Srikanth Reddy on 4/12/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionViewOutlet.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: movies[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index:indexPath)
    }
    func assignMovieDetails(index:IndexPath){
        
        
        titleOutlet.text = "movie title:\(movies[index.row].title)"
        
        yearReleasedOutlet.text = "year released: \(movies[index.row].releasedYear)"
       ratingsOutlet.text = "ratings:\(movies[index.row].movieRating)"
        revenueOutlet.text = "revenue:\(movies[index.row].boxOffice)"
    }
    
    
    @IBOutlet weak var collectionViewOutlet: UICollectionView!
    
    @IBOutlet weak var titleOutlet: UILabel!
    
    
    @IBOutlet weak var yearReleasedOutlet: UILabel!
    
    
    @IBOutlet weak var ratingsOutlet: UILabel!
    
    @IBOutlet weak var revenueOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
  

    collectionViewOutlet.delegate = self
    collectionViewOutlet.dataSource = self
     
    }
}

