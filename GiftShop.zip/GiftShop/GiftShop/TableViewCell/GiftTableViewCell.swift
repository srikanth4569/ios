//
//  GiftTableViewCell.swift
//   GiftShop
//
//  Created by Ali Sher on 07/04/2022.
//

import UIKit

class GiftTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var contantView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var quantityLbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
