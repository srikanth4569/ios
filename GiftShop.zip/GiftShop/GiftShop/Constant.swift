//
//  Constant.swift
//  GiftShop
//
// Created by GroupProject on 02/04/2022.
//

import UIKit
import AVFoundation

class Constant: NSObject {
    
    public static var BackgroundColor = UIColor(named: "Background")!
    public static var CellColor = UIColor(named: "CellColor")!
    public static var ThemeColor = UIColor(named: "ThemeColor")!
}
