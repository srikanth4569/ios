//
//  LoginViewController.swift
//  GiftShop
//
//  Created by GroupProject on 02/04/2022.
//

import UIKit
import Toast


class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var contantView: UIView!
    @IBOutlet var emailTF: UITextField!
    @IBOutlet var passwordTF: UITextField!
    
    @IBOutlet var loginBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginBtn.layer.cornerRadius = 8
        contantView.layer.cornerRadius = 16
    }
    
    
    @IBAction func loginBtnClicked(_ sender: Any) {
        
        //if emailTF.text == "" {
            
          //  self.view.makeToast("Please enter email")
        //}else if passwordTF.text == "" {
            
            //self.view.makeToast("Please enter password")
        //}else{
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "GiftsViewController") as! GiftsViewController
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
            
        //}
        
    }
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
    }
    
    
}
