//
//  AddNewGiftViewController.swift
//  GiftShop
//
//  Created by GroupProject on 02/04/2022.
//

import UIKit

class AddNewGiftViewController: UIViewController {
    
    
    @IBOutlet weak var coverImgView: UIImageView!
    
    @IBOutlet weak var detailsTextView: UITextView!
    
    @IBOutlet weak var weddingIcon: UIImageView!
    @IBOutlet weak var birthdayIcon: UIImageView!
    @IBOutlet weak var babyIcon: UIImageView!
    
    var type = "Wedding"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Add New Gift"
        
        detailsTextView.layer.cornerRadius = 8
        detailsTextView.layer.borderColor = UIColor.lightGray.cgColor
        detailsTextView.layer.borderWidth = 0.5
        
        let save = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(save))
        navigationItem.rightBarButtonItems = [save]
        
    }
    
    @objc func save() -> Void {
        
        
    }
    
    
    func setIcons() -> Void {
        
        weddingIcon.image = UIImage(named: "unchecked")
        birthdayIcon.image = UIImage(named: "unchecked")
        babyIcon.image = UIImage(named: "unchecked")
        
        if type == "Wedding" {
            
            weddingIcon.image = UIImage(named: "checked")
        }else if type == "Birthday" {
            
            birthdayIcon.image = UIImage(named: "checked")
        }else{
            
            babyIcon.image = UIImage(named: "checked")
        }
    }
    
    @IBAction func weddingBtnClicked(_ sender: Any) {
        
        type = "Wedding"
        self.setIcons()
    }
    
    @IBAction func birthdayBtnClicked(_ sender: Any) {
        
        type = "Birthday"
        self.setIcons()
    }
    
    @IBAction func babyBtnClicked(_ sender: Any) {
        
        type = "Baby"
        self.setIcons()
    }
    
    
    @IBAction func selectImgBtnClicked(_ sender: Any) {
        
        let obj = SelectImage()
        obj.VC = self
        obj.delegate = self
        obj.select()
        
    }
    
}

extension AddNewGiftViewController : UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.originalImage] as? UIImage

        
        if let image = image {
            
            coverImgView.image = image
        }
        picker.dismiss(animated: true)

    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    
}
