//
//  RegisterViewController.swift
//  GiftShop
//
//  Created by Ali Sher on 07/04/2022.
//

import UIKit

class RegisterViewController: UIViewController {
    
    
    @IBOutlet weak var contantView: UIView!
    @IBOutlet var backView: UIView!
    @IBOutlet var nameTF: UITextField!
    @IBOutlet var emailTF: UITextField!
    @IBOutlet var passwordTF: UITextField!
    
    @IBOutlet var registerBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        backView.layer.cornerRadius = backView.frame.size.height * 0.5
        registerBtn.layer.cornerRadius = 8
        contantView.layer.cornerRadius = 16
        
    }
    
    
    @IBAction func backBtnClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        
        if nameTF.text == "" {
            
            self.view.makeToast("Please enter name")
        }else if emailTF.text == "" {
            
            self.view.makeToast("Please enter email")
        }else if passwordTF.text == "" {
            
            self.view.makeToast("Please enter password")
        }else{
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "myTabBar") as! UITabBarController
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
            
        }
    }
    
    @IBAction func alreadyAccountBtnClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
