//
//  GiftsViewController.swift
//   GiftShop
//
//  Created by GroupProject on 02/04/2022.
//

import UIKit

class GiftsViewController: UIViewController {
    
       
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTF: UITextField!
    
    @IBOutlet weak var weddingBtn: UIButton!
    @IBOutlet weak var birthdayBtn: UIButton!
    @IBOutlet weak var babyBtn: UIButton!
    
    
    @IBOutlet var dataTableView: UITableView!
    
    var option = "Wedding"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBarController?.tabBar.isHidden = true
        self.navigationItem.hidesBackButton = true
        self.navigationItem.title = "Gifts List"
        
        dataTableView.backgroundColor = .clear
        dataTableView.delegate = self
        dataTableView.dataSource = self
        
        let confirm = UIBarButtonItem(title: "Add New", style: .plain, target: self, action: #selector(addNew))
        navigationItem.rightBarButtonItems = [confirm]
        
        self.searchView.layer.cornerRadius = 8
        self.setButtons()
    }
    
    
    @objc func addNew() -> Void {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "AddNewGiftViewController") as! AddNewGiftViewController
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = false
    }
    
    func setButtons() -> Void {
        
        weddingBtn.layer.cornerRadius = 8
        weddingBtn.backgroundColor = Constant.CellColor
        
        birthdayBtn.layer.cornerRadius = 8
        birthdayBtn.backgroundColor = Constant.CellColor
        
        babyBtn.layer.cornerRadius = 8
        babyBtn.backgroundColor = Constant.CellColor
        
        if option == "Wedding" {
            
            weddingBtn.backgroundColor = Constant.ThemeColor
        }else if option == "Birthday" {
            
            birthdayBtn.backgroundColor = Constant.ThemeColor
        }else{
            
            babyBtn.backgroundColor = Constant.ThemeColor
        }
        
        dataTableView.reloadData()
    }
    
    @IBAction func weddingBtnClicked(_ sender: Any) {
        
        option = "Wedding"
        self.setButtons()
        
    }
    
    @IBAction func birthdayBtnClicked(_ sender: Any) {
        
        option = "Birthday"
        self.setButtons()
        
    }
    
    @IBAction func babyBtnClicked(_ sender: Any) {
        
        option = "Baby"
        self.setButtons()
    }
}


extension GiftsViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 8
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("GiftTableViewCell", owner: self, options: nil)?.first as! GiftTableViewCell
        cell.backgroundColor = .clear
        cell.selectionStyle = .none
        
        cell.contantView.layer.cornerRadius = 12
        cell.contantView.clipsToBounds = true
        
        cell.nameLbl.text = option
        cell.imgView.image = UIImage(named: "\(option.lowercased()).jpeg")
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 116
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}
