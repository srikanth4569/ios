//
//  DetailsViewController.swift
//  GiftShop
//
//  Created by Ali Sher on 07/04/2022.
//

import UIKit

class DetailsViewController: UIViewController {
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet var saveView: UIView!
    @IBOutlet var readView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.isHidden = true
        backView.layer.cornerRadius = backView.frame.size.height * 0.5
        saveView.layer.cornerRadius = saveView.frame.size.height * 0.5
        readView.layer.cornerRadius = readView.frame.size.height * 0.5
    }
    
    
    @IBAction func backBtnClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
}
