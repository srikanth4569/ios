//
//  ViewController.swift
//  dice
//
//  Created by srinivasa Bhumipalli on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var diplay: UILabel!
    
    @IBOutlet weak var dice1: UILabel!
    
    @IBOutlet weak var dice2: UILabel!
    var number = [1,2,3,4,5,6]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func roll(_ sender: UIButton) {
        let firstNumber = arc4random_uniform(5) + 1
        let secondNumber = arc4random_uniform(5) + 1
        if firstNumber > secondNumber
        {
            
            diplay.text = "dice1 is the winner"
        }
        else if firstNumber < secondNumber {
            
            diplay.text = "dice2 is the winner"
        }
        else {
            diplay.text = " its a tie"
        }
        dice1.text = String(Int(firstNumber))
        dice2.text = String(Int(secondNumber))
    }
    
}

